#ifndef S_DES_FUNCTION_H
#define S_DES_FUNCTION_H

#include <iostream>
#include <string>
#include <algorithm>

class SDES {
private:
    int key[10];      //10-bit main key
    int k1[8], k2[8]; //store subkeys
    int text[8];      //8-bit plaintext or ciphertext (depending on the operation)

    const int IP[8] = {2, 6, 3, 1, 4, 8, 5, 7};         //Initial Permutation (IP)
    const int IP_inv[8] = {4, 1, 3, 5, 7, 2, 8, 6};     //Inverse Initial Permutation (IP⁻¹)
    const int P10[10] = {3, 5, 2, 7, 4, 10, 1, 9, 8, 6};    //P10 permutation
    const int P8[8] = {6, 3, 7, 4, 8, 5, 10, 9};        //P8 permutation
    const int P4[4] = {2, 4, 3, 1};                     //P4 permutation
    const int E_P[8] = {4, 1, 2, 3, 2, 3, 4, 1};         //Expansion/Permutation (E/P)
    const int S0[4][4] = {{1, 0, 3, 2}, {3, 2, 1, 0}, {0, 2, 1, 3}, {3, 1, 3, 2}};  //S-box S0
    const int S1[4][4] = {{0, 1, 2, 3}, {2, 0, 1, 3}, {3, 0, 1, 0}, {2, 1, 0, 3}};  //S-box S1

public:
    void permutation(const int input[], int output[], const int rule[], int size);
    void leftShift(int arr[], int n, int shifts);  //left shift bits in the array
    void XOR(int* arr1, int* arr2, int length);    //XOR operation on two arrays
    int bin2dec(int* arr, int size);   //convert binary to decimal
    void dec2bin(int val, int* arr);   //convert decimal to binary
    void feistel(int* right, int* subkey, int* output);  
    void generateKeys();  //generate two subkeys
    void encrypt();  //encrypt the plaintext
    void decrypt();  //decrypt the ciphertext
    void runSDES(); //run the program
};

//perform permutation
void SDES::permutation(const int input[], int output[], const int rule[], int size) {
    for (int i = 0; i < size; i++) {
        output[i] = input[rule[i] - 1];  // Permute input array based on the rule
    }
}

//shift array to left
void SDES::leftShift(int arr[], int n, int shifts) {
    for (int s = 0; s < shifts; s++) {
        int temp = arr[0];
        for (int i = 0; i < n - 1; i++) {
            arr[i] = arr[i + 1];
        }
        arr[n - 1] = temp;
    }
}

//XOR two arrays 
void SDES::XOR(int* arr1, int* arr2, int length) {
    for (int i = 0; i < length; i++) {
        arr1[i] = arr1[i] ^ arr2[i];  // XOR corresponding bits
    }
}

//convert a binary array to decimal integer
int SDES::bin2dec(int* arr, int size) {
    int decimal = 0;
    for (int i = 0; i < size; i++) {
        decimal = (decimal << 1) | arr[i];  
    }
    return decimal;
}

//convert a decimal integer to binary array
void SDES::dec2bin(int val, int* arr) {
    arr[0] = (val >> 1) & 1;
    arr[1] = val & 1;         
}

//Feistel function, applying S-boxes and permutation
void SDES::feistel(int* right, int* subkey, int* output) {
    int expanded[8];  // Expanded right half of the input
    
    //expansion/permutation (E/P)
    permutation(right, expanded, E_P, 8);
    
    //XOR the expanded right half with the subkey
    XOR(expanded, subkey, 8);
    
    //split the expanded result into two halves for S-box lookups
    int left[4] = {expanded[0], expanded[1], expanded[2], expanded[3]};
    int right_half[4] = {expanded[4], expanded[5], expanded[6], expanded[7]};
    
    //apply S-boxes to both halves
    int row0 = (left[0] << 1) | left[3];  //get first and last bits for row
    int col0 = (left[1] << 1) | left[2];  //get second and third bits for col
    int sbox_output_0 = S0[row0][col0];   //apply row and col to sbox0

    int row1 = (right_half[0] << 1) | right_half[3];
    int col1 = (right_half[1] << 1) | right_half[2];
    int sbox_output_1 = S1[row1][col1];

    //convert S-box outputs to binary and combine
    int sbox_output[4];
    dec2bin(sbox_output_0, sbox_output);      //convert S0 output
    dec2bin(sbox_output_1, sbox_output + 2);  //convert S1 output

    //apply P4 permutation to S-box output
    permutation(sbox_output, output, P4, 4);
}

//generate two subkeys
void SDES::generateKeys() {
    string keyInput;

    //loop until the user enters a valid 10-bit key
    do {
        cout << "Enter the 10-bit key (without spaces): ";
        cin >> keyInput;
        if (keyInput.length() != 10 || keyInput.find_first_not_of("01") != string::npos) {
            cout << "Error: Invalid 10-bit key. Please enter a valid binary key.\n";
        }
    } while (keyInput.length() != 10 || keyInput.find_first_not_of("01") != string::npos); // Validate input

    //convert the key input from string to integer array
    for (int i = 0; i < 10; i++) {
        key[i] = keyInput[i] - '0';
    }

    int temp[10];   //temporary array for storing permuted key
    int left[5], right[5];  //left and right halves of the key

    //apply P10 to the key
    permutation(key, temp, P10, 10);

    //split into two halves
    for (int i = 0; i < 5; i++) {
        left[i] = temp[i]; //get first 5 bits
        right[i] = temp[i + 5]; // get second 5 bits
    }

    //left shift both halves by 1 to generate k1
    leftShift(left, 5, 1);
    leftShift(right, 5, 1);

    //combine and apply P8 to generate k1
    for (int i = 0; i < 5; i++) {
        temp[i] = left[i];
        temp[i + 5] = right[i];
    }
    permutation(temp, k1, P8, 8);

    //display Key 1 
    cout << "Generated Key 1 (k1): ";
    for (int i = 0; i < 8; i++) {
        cout << k1[i];
    }
    cout << endl;

    //left shift both halves by 2 to generate k2
    leftShift(left, 5, 2);
    leftShift(right, 5, 2);

    //combine and apply P8 to generate k2
    for (int i = 0; i < 5; i++) {
        temp[i] = left[i];
        temp[i + 5] = right[i];
    }
    permutation(temp, k2, P8, 8);

    //display Key 2
    cout << "Generated Key 2 (k2): ";
    for (int i = 0; i < 8; i++) {
        cout << k2[i];
    }
    cout << endl;
}

//encryption
void SDES::encrypt() {
    generateKeys(); //generate subkeys
    string textInput;

    //loop until the user enters a valid 8-bit plaintext
    do {
        cout << "Enter the 8-bit plaintext: ";
        cin >> textInput;
        if (textInput.length() != 8 || textInput.find_first_not_of("01") != string::npos) {
            cerr << "Error: Invalid 8-bit plaintest. Please enter a valid binary input.\n";
        }
    } while (textInput.length() != 8 || textInput.find_first_not_of("01") != string::npos);  // Validate input

    //convert the plaintext input from string to integer array
    for (int i = 0; i < 8; i++) {
        text[i] = textInput[i] - '0';
    }

    int ip[8];  
    int l[4], r[4];  
    int temp[4];  

    //apply Initial Permutation (IP)
    permutation(text, ip, IP, 8);

    //split the result into left and right halves
    for (int i = 0; i < 4; i++) {
        l[i] = ip[i];
        r[i] = ip[i + 4];
    }

    //first round of Feistel with subkey k1
    feistel(r, k1, temp);  //Feistel function on the right half with k1
    XOR(l, temp, 4);  //XOR the left half with Feistel output

    //swap left and right for the second round
    int swapped_l[4], swapped_r[4];
    for (int i = 0; i < 4; i++) {
        swapped_l[i] = r[i];  //old right half becomes the new left
        swapped_r[i] = l[i];  //result of XOR becomes the new right
    }

    //second round of Feistel with subkey k2
    feistel(swapped_r, k2, temp);  //Feistel function on the new right half with k2
    XOR(swapped_l, temp, 4);  //XOR the new left half with Feistel output

    //combine the left and right halves
    int pre_output[8];
    for (int i = 0; i < 4; i++) {
        pre_output[i] = swapped_l[i];
        pre_output[i + 4] = swapped_r[i];
    }

    //apply Inverse Initial Permutation (IP⁻¹)
    permutation(pre_output, text, IP_inv, 8);

    //display the encrypted ciphertext
    cout << "Encrypted ciphertext: ";
    for (int i = 0; i < 8; i++) {
        cout << text[i];
    }
    cout << endl;
}

//decryption
void SDES::decrypt() {
    generateKeys();  // Generate subkeys 
    string textInput;

    //loop until the user enters a valid 8-bit ciphertext
    do {
        cout << "Enter the 8-bit ciphertext: ";
        cin >> textInput;
        if (textInput.length() != 8 || textInput.find_first_not_of("01") != string::npos) {
            cerr << "Error: Invalid 8-bit ciphertext. Please enter a valid binary input.\n";
        }
    } while (textInput.length() != 8 || textInput.find_first_not_of("01") != string::npos);  // Validate input

    //convert the ciphertext input from string to integer array
    for (int i = 0; i < 8; i++) {
        text[i] = textInput[i] - '0';
    }

    int ip[8];  
    int l[4], r[4];  
    int temp[4];  

    //apply Initial Permutation (IP)
    permutation(text, ip, IP, 8);

    //split the result into left and right halves
    for (int i = 0; i < 4; i++) {
        l[i] = ip[i];
        r[i] = ip[i + 4];
    }

    //first round of Feistel with subkey k2 
    feistel(r, k2, temp);  //Feistel function on the right half with k2
    XOR(l, temp, 4);  //XOR the left half with Feistel output

    //swap left and right for the second round
    int swapped_l[4], swapped_r[4];
    for (int i = 0; i < 4; i++) {
        swapped_l[i] = r[i];  //old right half becomes the new left
        swapped_r[i] = l[i];  //result of XOR becomes the new right
    }

    //Second round of Feistel with subkey k1
    feistel(swapped_r, k1, temp);  //feistel function on the new right half with k1
    XOR(swapped_l, temp, 4);  //XOR the new left half with Feistel output

    //Combine the left and right halves
    int pre_output[8];
    for (int i = 0; i < 4; i++) {
        pre_output[i] = swapped_l[i];
        pre_output[i + 4] = swapped_r[i];
    }

    //Apply Inverse Initial Permutation (IP⁻¹)
    permutation(pre_output, text, IP_inv, 8);

    //display the decrypted plaintext
    cout << "Decrypted plaintext: ";
    for (int i = 0; i < 8; i++) {
        cout << text[i];
    }
    cout << endl;
}

void SDES::runSDES(){
    int choice;

    do {
        cout << "Would you like to encrypt or decrypt for your S-DES system?\n"
            <<"1) Encryption\n"
            <<"2) Decryption\n"
            <<"3) Exit\n";
        cin >> choice;

        switch(choice){
            case 1:
                cout << "Running encryption for SDES." << endl;
                encrypt();
                break;
            case 2:
                cout << "Running decryption for SDES." << endl;
                decrypt();
                break;
            case 3:
                cout << "Return to main menu" << endl;
                break;
            default:
                cout << "Invalid choice. Please enter again: " << endl;
        }
        
    } while (choice !=3);
}
#endif

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>

using namespace std;

#include "S-DES_function.h"
#include "RSA_function.h"

int main(){
    SDES sdes; 
    RSA rsa;

    srand(time(0));
    int choice;

    do {
        cout << "Would you like to run SDES or RSA system?\n"
            <<"1) SDES\n"
            <<"2) RSA\n"
            <<"3) Exit\n";
        cin >> choice;

        switch(choice){
            case 1:
                cout << "Running SDES program." << endl;
                sdes.runSDES(); //run SDES file
                break;
            case 2:
                cout << "Running RSA program." << endl;
                rsa.runRSA(); //run RSA file
                break;
            case 3:
                cout << "Exiting program" << endl; //exit the program
                break;
            default:
                cout << "Invalid choice. Please enter again: " << endl;
        }
        
    } while (choice !=3);

    return 0;
}
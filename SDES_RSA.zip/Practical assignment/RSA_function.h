#ifndef RSA_FUNCTION_H
#define RSA_FUNCTION_H

#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>

using namespace std;

/*
RSA Class
e = public key
d = private key
m = message
c = ciphertext
*/

class RSA {
private:
    int primeLimit = 100;  // Limit for generating prime numbers

public:
    int gcd(int a, int b); //gcd 
    int modInverse(int e, int phi_n); //modular inverse
    int squareAndMultiply(int base, int exp, int mod); //
    vector<int> generatePrimeNum(int primeLimit); //generate using Sieve of Eratosthenes
    int getRandomPrime();   //get random prime
    vector<int> listValidExponents(int phi_n);
    void autoRSA(); //auto RSA
    void manualRSA();   //manual RSA
    bool isPrime(int num); //valid prime
    void printPrime(); //display prime numbers
    void runRSA();
};

//compute GCD (Greatest Common Divisor)
int RSA::gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

//Extended Euclidean Algorithm to compute the modular inverse of e mod phi_n
int RSA::modInverse(int e, int phi_n) {
    int t = 0, newT = 1;
    int r = phi_n, newR = e;

    while (newR != 0) {
        int quotient = r / newR;

        // Update t and newT
        int tempT = t;
        t = newT;
        newT = tempT - quotient * newT;

        // Update r and newR
        int tempR = r;
        r = newR;
        newR = tempR - quotient * newR;
    }

    // If t is negative, adjust it to be positive
    if (t < 0) {
        t += phi_n;
    }

    return t;
}

//Square and Multiply for encryption and decryption
int RSA::squareAndMultiply(int base, int exp, int mod) {
    int d = 1;  // Result, initialized to 1
    int c = 0;  // Counter or bit position

    // Convert exp (b) to its binary form and process each bit from MSB to LSB
    for (int i = log2(exp); i >= 0; i--) {
        c = 2 * c;  // Double the counter

        // Square step: d = d * d mod n
        d = (d * d) % mod;

        // If the current bit is 1, multiply by the base
        if ((exp >> i) & 1) {
            c = c + 1;
            d = (d * base) % mod;
        }
    }

    return d;  // Return the final result
}

//Sieve of Eratosthenes to generate all prime numbers
vector<int> RSA::generatePrimeNum(int primeLimit) {
    vector<bool> isPrime(primeLimit + 1, true);
    vector<int> primes;

    isPrime[0] = isPrime[1] = false;  // 0 and 1 are not primes
    for (int i = 2; i * i <= primeLimit; ++i) {
        if (isPrime[i]) {
            for (int j = i * i; j <= primeLimit; j += i) {
                isPrime[j] = false;
            }
        }
    }

    // Collect all primes
    for (int i = 2; i <= primeLimit; ++i) {
        if (isPrime[i]) {
            primes.push_back(i);
        }
    }

    return primes;
}

//get random prime for auto
int RSA::getRandomPrime() {
    vector<int> primes = generatePrimeNum(primeLimit);
    return primes[rand() % primes.size()];  //randomly select a prime from array
}

//list all valid public exponents e such that gcd(e, φ(n)) = 1
vector<int> RSA::listValidExponents(int phi_n) {
    vector<int> validExponents; //store exponents
    for (int e = 2; e < phi_n; ++e) {
        if (gcd(e, phi_n) == 1) { 
            validExponents.push_back(e); //put
        }
    }
    return validExponents;
}

//validate prime number
bool RSA::isPrime(int num) {
    if (num < 2) return false;  //0 and 1 are not prime
    for (int i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) {  //If num is divisible by any number between 2 and sqrt(num)
            return false;    
        }
    }
    return true;  // num is prime if no divisors are found
}

void RSA::printPrime() {
    vector<int> primes = generatePrimeNum(primeLimit);
    cout << "Generated prime numbers up to " << primeLimit << ": ";
    for (std::size_t i = 0; i < primes.size(); ++i) {
        cout << primes[i] << " "; //print prime number
    }
    cout << endl;
}

//Automatically 
void RSA::autoRSA() {
    int p, q, n, phi_n, e, d, m, c, decryptedMessage;

    //randomly select primes p and q
    p = getRandomPrime();
    q = getRandomPrime();
    while (p == q) {  // Ensure p and q are different
        q = getRandomPrime();
    }
    cout << "primes: p = " << p << ", q = " << q << endl;

    //randomly select public exponent e
    phi_n = (p - 1) * (q - 1);
    vector<int> validExponents = listValidExponents(phi_n);
    e = validExponents[rand() % validExponents.size()];
    cout << "public exponent e = " << e << endl;

    //compute n = p * q and the private exponent d (modular inverse of e mod φ(n))
    n = p * q;
    d = modInverse(e, phi_n);

    cout << "Public key: (e = " << e << ", n = " << n << ")" << endl;
    cout << "Private key: (d = " << d << ", n = " << n << ")" << endl;

    //encryption
    do {
        cout << "Enter a message (integer) to encrypt (m < " << n << "): ";
        cin >> m;

        if (m >= n) {
            cout << "Error: Message m must be less than n!" << endl;
        }
    } while (m >= n);  // Keep asking until m is valid

    //encrypt the message: c = m^e mod n
    c = squareAndMultiply(m, e, n);
    cout << "Encrypted message (ciphertext) c = " << c << endl;

    //decryption
    //decrypt the ciphertext: m = c^d mod n
    decryptedMessage = squareAndMultiply(c, d, n);
    cout << "Decrypted message = " << decryptedMessage << endl;
}

//manual
void RSA::manualRSA() {
    int p, q, n, phi_n, e, d, m, c, decryptedMessage;

    printPrime(); //display prime numbers

    //User inputs primes p and q
    cout << "Enter prime number p (<= 100): ";
    cin >> p;
    while (!isPrime(p)) {
        cout << "Invalid input. Enter a valid prime number p (<= 100): ";
        cin >> p;
    }

    cout << "Enter a different prime number q (<= 100): ";
    cin >> q;
    while (!isPrime(q) || p == q) {
        cout << "Invalid input. Enter a valid and different prime number q (<= 100): ";
        cin >> q;
    }

    cout << "You entered: p = " << p << ", q = " << q << endl;

    //list all valid public exponents e such that 1 < e < φ(n) and gcd(e, φ(n)) = 1
    phi_n = (p - 1) * (q - 1);
    vector<int> validExponents = listValidExponents(phi_n);
    cout << "Valid public exponents e (1 < e < " << phi_n << ") are: ";
    for (int exp : validExponents) {
        cout << exp << " ";
    }
    cout << endl;

    //choose e from the list of valid exponents
    cout << "Select a public exponent e from the list: ";
    cin >> e;
    while (find(validExponents.begin(), validExponents.end(), e) == validExponents.end()) {
        cout << "Invalid e! Choose a valid e from the list: ";
        cin >> e;
    }

    //compute n = p * q and the private exponent d (modular inverse of e mod φ(n))
    n = p * q;
    d = modInverse(e, phi_n);

    cout << "Public key: (e = " << e << ", n = " << n << ")" << endl;
    cout << "Private key: (d = " << d << ", n = " << n << ")" << endl;

    //encryption
    do {
        cout << "Enter a message (integer) to encrypt (m < " << n << "): ";
        cin >> m;

        if (m >= n) {
            cout << "Error: Message m must be less than n!" << endl;
        }
    } while (m >= n); 

    //encrypt the message: c = m^e mod n
    c = squareAndMultiply(m, e, n);
    cout << "Encrypted message (ciphertext) c = " << c << endl;

    //decryption
    //decrypt the ciphertext: m = c^d mod n
    decryptedMessage = squareAndMultiply(c, d, n);
    cout << "Decrypted message = " << decryptedMessage << endl;
}

void RSA::runRSA() {
    int choice;

    do {
        cout << "Would you like to automatic or manual for your RSA system?\n"
            <<"1) Automatic RSA\n"
            <<"2) Manual RSA\n"
            <<"3) Exit\n";
        cin >> choice;

        switch(choice){
            case 1:
                cout << "Running automatic RSA." << endl;
                autoRSA();
                break;
            case 2:
                cout << "Running manual RSA." << endl;
                manualRSA();
                break;
            case 3:
                cout << "Return to main menu" << endl;
                break;
            default:
                cout << "Invalid choice. Please enter again: " << endl;
        }
        
    } while (choice !=3);
}

#endif